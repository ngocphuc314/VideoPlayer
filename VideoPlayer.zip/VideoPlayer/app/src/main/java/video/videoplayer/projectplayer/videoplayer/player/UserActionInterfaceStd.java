package video.videoplayer.projectplayer.videoplayer.player;


public interface UserActionInterfaceStd extends UserActionInterface {

    int ON_CLICK_START_THUMB = 101;
    int ON_CLICK_BLANK = 102;
    int ON_CLICK_START_WIFIDIALOG = 103;

}
