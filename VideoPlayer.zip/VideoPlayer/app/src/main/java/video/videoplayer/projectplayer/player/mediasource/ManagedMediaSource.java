package video.videoplayer.projectplayer.player.mediasource;

import android.support.annotation.NonNull;

import com.google.android.exoplayer2.source.MediaSource;
import video.videoplayer.projectplayer.player.playqueue.PlayQueueItem;

public interface ManagedMediaSource extends MediaSource {

    boolean shouldBeReplacedWith(@NonNull final PlayQueueItem newIdentity,
                                 final boolean isInterruptable);

    boolean isStreamEqual(@NonNull final PlayQueueItem stream);
}
