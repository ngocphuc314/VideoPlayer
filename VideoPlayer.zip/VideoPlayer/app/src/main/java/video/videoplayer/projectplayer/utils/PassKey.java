package video.videoplayer.projectplayer.utils;

public class PassKey {

    public static long PLAYER_SEEK = -1;
}
