package video.videoplayer.projectplayer.utils;

import java.util.ArrayList;

public class Utils {
    public static String FOLDER_NAME = "WV VideoPlayer";
    public static int isWhatsapp = -1;
    public static ArrayList<String> mainPlayList = new ArrayList<>();
    public static int playPosition;
    public static int listSize;
    public static boolean isPopup = false;
    public static ArrayList<String> popupList;
    public static boolean isAd = false;
}
