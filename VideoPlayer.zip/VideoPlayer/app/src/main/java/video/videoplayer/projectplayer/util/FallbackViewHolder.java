package video.videoplayer.projectplayer.util;

import android.support.v7.widget.RecyclerView;
import android.view.View;

public class FallbackViewHolder extends RecyclerView.ViewHolder {
    public FallbackViewHolder(View itemView) {
        super(itemView);
    }
}
